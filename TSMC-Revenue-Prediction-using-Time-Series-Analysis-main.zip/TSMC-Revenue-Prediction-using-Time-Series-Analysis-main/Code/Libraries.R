# install.packages("reshape2")
# install.packages("dplyr")
# install.packages("tseries")
# install.packages("ggfortify")
# install.packages("fpp2")
# install.packages("Metrics")
# install.packages("seastests")
# install.packages("gridExtra")
# install.packages("ggplot2")
# install.packages("scales")
# install.packages("prophet")
# install.packages("tidyverse")
# install.packages("ggpmisc")
# install.packages("grid")
# install.packages("knitr")
# install.packages("kableExtra")
library(reshape2)
library(dplyr)
library(tseries)
library(ggfortify)
library(fpp2)
library(Metrics)
library(seastests)
library(gridExtra)
library(ggplot2)
library(scales)
library(prophet)
library(tidyverse)
library(ggpmisc)
library(grid)
library(knitr)
library(kableExtra)

load("TSMC.RData")

temp <- load("TSMC.RData")  # temp will store the names of loaded objects

timeseries <- get(temp)          # get() fetches the object by name





